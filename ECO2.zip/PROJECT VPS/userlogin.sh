#!/bin/bash
clear
	echo -e "+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+" | lolcat -F 0.2
	echo -e "+                                                                             +" | lolcat -F 0.2
	echo -e "+                     Premium Script Modified by BaBaNET                      +" | lolcat -F 0.2
	echo -e "+             Contact Us >> WA : +6285790808469 or BBM : D7FD3D6F             +" | lolcat -F 0.2
	echo -e "+                                                                             +" | lolcat -F 0.2
	echo -e "+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+" | lolcat -F 0.2
	echo -e "===============================================================================" | lolcat -F 0.2
	echo -e "                   >>>>>>>>>> Cek Login Akun SSH <<<<<<<<<<                    " | lolcat -F 0.2
	echo -e "===============================================================================" | lolcat -F 0.2
	echo ""

data=( `ps aux | grep -i dropbear | awk '{print $2}'`);
echo "====================================" | lolcat -F 0.2
echo "Checking Dropbear login" | lolcat -F 0.2
echo "------------------------------------" | lolcat -F 0.2
for PID in "${data[@]}"
do
	#echo "check $PID";
	NUM=`cat /var/log/auth.log | grep -i dropbear | grep -i "Password auth succeeded" | grep "dropbear\[$PID\]" | wc -l`;
	username=`cat /var/log/auth.log | grep -i dropbear | grep -i "Password auth succeeded" | grep "dropbear\[$PID\]" | awk '{print $10}'`;
	IP=`cat /var/log/auth.log | grep -i dropbear | grep -i "Password auth succeeded" | grep "dropbear\[$PID\]" | awk '{print $12}'`;
	if [ $NUM -eq 1 ]; then
		echo "$PID - $username - $IP" | lolcat -F 0.2
	fi
done

echo "";

data=( `ps aux | grep "\[priv\]" | sort -k 72 | awk '{print $2}'`);
echo "====================================" | lolcat -F 0.2
echo "Checking OpenSSH login" | lolcat -F 0.2
echo "------------------------------------" | lolcat -F 0.2
for PID in "${data[@]}"
do
	#echo "check $PID";
	NUM=`cat /var/log/auth.log | grep -i sshd | grep -i "Accepted password for" | grep "sshd\[$PID\]" | wc -l`;
	username=`cat /var/log/auth.log | grep -i sshd | grep -i "Accepted password for" | grep "sshd\[$PID\]" | awk '{print $9}'`;
	IP=`cat /var/log/auth.log | grep -i sshd | grep -i "Accepted password for" | grep "sshd\[$PID\]" | awk '{print $11}'`;
	if [ $NUM -eq 1 ]; then
		echo "$PID - $username - $IP" | lolcat -F 0.2
	fi
done

echo "";
echo "------------------------------------" | lolcat -F 0.2
echo ">>>>>>   MODIFIED BY BaBaNET  <<<<<<" | lolcat -F 0.2
echo "====================================" | lolcat -F 0.2
echo ""

cd ~/
rm -f /root/IP
