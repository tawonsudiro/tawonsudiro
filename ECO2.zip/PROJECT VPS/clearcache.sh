#!/bin/bash
clear
	echo -e "===========( MENU BANNED )=============="    | boxes -d dog| lolcat -F 0.2
	echo -e "   ========================================" | lolcat -F 0.2
	echo -e "          SCRIPT MODD BY TAWONSUDIRO       " | lolcat -F 0.2
	echo -e "   WhatsApp Kami  : +6283148123457         " | lolcat -F 0.2
	echo -e "   FB Group       : GKNIGHT REBORN SSH     " | lolcat -F 0.2
	echo -e "   ========================================" | lolcat -F 0.2
	echo -e "   YOUTUBE CHANNEL: GKNIGHT GG             " | lolcat -F 0.2
	echo -e "                  : GKNIGHT REBORN         " | lolcat -F 0.2
	echo -e "   ========================================" | lolcat -F 0.2
echo "Status Memory Sebelum dibersihkan" | lolcat -F 0.2
free -m
sync; echo 1 > /proc/sys/vm/drop_caches
echo ""
echo "Status Memory Sesudah dibersihkan" | lolcat -F 0.2
free -m
