#!/bin/bash
if [[ $USER != 'root' ]]; then
	echo "Maaf, Anda harus menjalankan ini sebagai root"
	exit
fi

MYIP=$(wget -qO- ipv4.icanhazip.com)
clear
	echo -e "=========================(WELLCOME)========================"    | boxes -d sunset| lolcat -F 0.2
	echo -e "              SCRIPT MODIFIKASI BY TAWONSUDIRO       " | lolcat -F 0.2
	echo -e "==================================================================" | lolcat -F 0.2
	echo -e "              WhatsApp Kami       : +6283148123457         " | lolcat -F 0.2
	echo -e "              Facebook            : GKNIGHT REBORN SSH     " | lolcat -F 0.2
	echo -e "              YOUTUBE CHANNEL     : GKNIGHT GG             " | lolcat -F 0.2
	echo -e "                                  : GKNIGHT REBORN         " | lolcat -F 0.2
	echo -e "==================================================================" | lolcat -F 0.2
	echo -e "============================( MENU BANNED)========================"| lolcat -F 0.2
	echo -e ""
	echo -e "  1. Banned Akun SSH                | lolcat -F 0.2
	echo -e "  2. Unbanned Akun SSH              | lolcat -F 0.2
	echo -e ""
	echo -e " x = Menu Utama"	 | lolcat -F 0.2
	echo -e ""
	read -p "Pilih dan  ENTER : " option1
	echo ""
	case $option1 in
		1)
		cd /root/baso/ && ./banned.sh
		exit
		;;
		2)
		cd /root/baso/ && ./unbanned.sh
		exit
		;;
		x)
		./minil.sh
		;;
	esac
done
