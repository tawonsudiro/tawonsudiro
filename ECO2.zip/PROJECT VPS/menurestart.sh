#!/bin/bash

if [[ $USER != 'root' ]]; then
	echo "Maaf, Anda harus menjalankan ini sebagai root"
	exit
fi

MYIP=$(wget -qO- ipv4.icanhazip.com)

	exit
clear

	cname=$( awk -F: '/model name/ {name=$2} END {print name}' /proc/cpuinfo )
	cores=$( awk -F: '/model name/ {core++} END {print core}' /proc/cpuinfo )
	freq=$( awk -F: ' /cpu MHz/ {freq=$2} END {print freq}' /proc/cpuinfo )
	tram=$( free -m | awk 'NR==2 {print $2}' )
	swap=$( free -m | awk 'NR==4 {print $2}' )
	up=$(uptime|awk '{ $1=$2=$(NF-6)=$(NF-5)=$(NF-4)=$(NF-3)=$(NF-2)=$(NF-1)=$NF=""; print }')
	date=$( date '+%A, %d %B %Y' )


	echo -e "   ========================================" | lolcat -F 0.2
	echo -e "          SCRIPT MODD BY TAWONSUDIRO       " | lolcat -F 0.2
	echo -e "   WhatsApp Kami  : +6283148123457         " | lolcat -F 0.2
	echo -e "   FB Group       : GKNIGHT REBORN SSH     " | lolcat -F 0.2
	echo -e "   ========================================" | lolcat -F 0.2
	echo -e "   YOUTUBE CHANNEL: GKNIGHT GG             " | lolcat -F 0.2
	echo -e "                  : GKNIGHT REBORN         " | lolcat -F 0.2
	echo -e "   ========================================" | lolcat -F 0.2
	echo -e "            Informasi Server Anda                             " | lolcat -F 0.2
	echo -e " IP/Host : $MYIP" | lolcat -F 0.2
	echo -e " Memory  : $tram MB" | lolcat -F 0.2
	echo -e " Date    : $date" | lolcat -F 0.2
	echo -e "===========( MENU RESTART )============="    | boxes -d dog| lolcat -F 0.2
	echo -e "  1. Restart SSH                         " | lolcat -F 0.2
	echo -e "  2. Restart Dropbear                   " | lolcat -F 0.2
	echo -e "  3. Restart Squid            " | lolcat -F 0.2
	echo -e "  4. Restart OpenVPN                        " | lolcat -F 0.2
	echo -e "  5. Restart Webmin              " | lolcat -F 0.2
	echo -e "  6. Restart Nginx                       " | lolcat -F 0.2
	echo -e "  7. Restart Fail2ban             " | lolcat -F 0.2
	echo -e "  8. Restart Server                    " | lolcat -F 0.2
	echo -e ""
	echo -e " x >> Keluar"	 | lolcat -F 0.2
	echo -e ""
	read -p "Masukkan pilihan anda, kemudian tekan tombol ENTER : " option1
	echo ""
	case $option1 in
		1)
		service ssh restart
		exit
		;;
		2)
		service dropbear restart
		exit
		;;
		3)
		service squid3 restart
		exit
		;;
		4)
		service openvpn restart
		exit
		;;
		5)
		service webmin restart
		exit
		;;
		6)
		service nginx start
		exit
		;;
		7)
		service fail2ban restart
		exit
		;;
		8)
		reboot
		exit
		;;
		x)
		cd /root
		
		exit
		;;
	esac
done
