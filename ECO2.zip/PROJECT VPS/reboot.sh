#!/bin/bash

if [[ $USER != 'root' ]]; then
	echo "Maaf, Anda harus menjalankan ini sebagai root"
	exit
fi

MYIP=$(wget -qO- ipv4.icanhazip.com)

	exit
clear

	cname=$( awk -F: '/model name/ {name=$2} END {print name}' /proc/cpuinfo )
	cores=$( awk -F: '/model name/ {core++} END {print core}' /proc/cpuinfo )
	freq=$( awk -F: ' /cpu MHz/ {freq=$2} END {print freq}' /proc/cpuinfo )
	tram=$( free -m | awk 'NR==2 {print $2}' )
	swap=$( free -m | awk 'NR==4 {print $2}' )
	up=$(uptime|awk '{ $1=$2=$(NF-6)=$(NF-5)=$(NF-4)=$(NF-3)=$(NF-2)=$(NF-1)=$NF=""; print }')
	date=$( date '+%A, %d %B %Y' )

	
	echo -e "   ========================================" | lolcat -F 0.2
	echo -e "          SCRIPT MODD BY TAWONSUDIRO       " | lolcat -F 0.2
	echo -e "   WhatsApp Kami  : +6283148123457         " | lolcat -F 0.2
	echo -e "   FB Group       : GKNIGHT REBORN SSH     " | lolcat -F 0.2
	echo -e "   ========================================" | lolcat -F 0.2
	echo -e "   YOUTUBE CHANNEL: GKNIGHT GG             " | lolcat -F 0.2
	echo -e "                  : GKNIGHT REBORN         " | lolcat -F 0.2
	echo -e "   ========================================" | lolcat -F 0.2
	echo -e "         Informasi Server Anda                             " | lolcat -F 0.2
	echo -e " IP/Host : $MYIP" | lolcat -F 0.2
	echo -e " Memory  : $tram MB" | lolcat -F 0.2
	echo -e " Date    : $date" | lolcat -F 0.2
	echo -e "=========( REBOOT TIME VPS )============"    | boxes -d dog| lolcat -F 0.2
	echo -e "  1. 30 Menit" | lolcat -F 0.2
	echo -e "  2.  1 Jam" | lolcat -F 0.2
	echo -e "  3.  2 Jam" | lolcat -F 0.2
	echo -e "  4.  4 Jam" | lolcat -F 0.2
	echo -e "  5.  6 Jam" | lolcat -F 0.2
	echo -e "  6.  8 Jam" | lolcat -F 0.2
	echo -e "  7. 12 Jam" | lolcat -F 0.2
	echo -e "  8.  1 Hari" | lolcat -F 0.2
	echo -e "  9.  2 Hari" | lolcat -F 0.2
	echo -e " 10.  7 Hari" | lolcat -F 0.2
	echo -e " 11. 14 Hari" | lolcat -F 0.2
	echo -e " 12. 30 Hari" | lolcat -F 0.2
	echo -e " 13. Hapus Auto Reboot" | lolcat -F 0.2
	echo -e " 14. Cek Auto Reboot Aktif" | lolcat -F 0.2
	echo -e ""
	echo -e " x >> Keluar"	 | lolcat -F 0.2
	echo -e ""
	read -p "Masukan Pilihan dan tekan ENTER : " option1
	echo ""
	case $option1 in
		1)
		rm /usr/bin/autoreboot.txt
		rm /etc/cron.d/reboot
		echo "0,30 * * * * root /sbin/reboot" > /etc/cron.d/reboot
		echo "Auto Reboot VPS tiap 30 Menit" > /usr/bin/autoreboot.txt
		echo ""
		cat /usr/bin/autoreboot.txt
		echo ""
		
		exit
		;;
		2)
		rm /usr/bin/autoreboot.txt
		rm /etc/cron.d/reboot
		echo "0 * * * * root /sbin/reboot" > /etc/cron.d/reboot
		echo "Auto Reboot VPS tiap 1 Jam" > /usr/bin/autoreboot.txt
		echo ""
		cat /usr/bin/autoreboot.txt
		echo ""
		
		exit
		;;
		3)
		rm /usr/bin/autoreboot.txt
		rm /etc/cron.d/reboot
		echo "0 */2 * * * root /sbin/reboot" > /etc/cron.d/reboot
		echo "Auto Reboot VPS tiap 2 Jam" > /usr/bin/autoreboot.txt
		echo ""
		cat /usr/bin/autoreboot.txt
		echo ""
		
		exit
		;;
		4)
		rm /usr/bin/autoreboot.txt
		rm /etc/cron.d/reboot
		echo "0 */4 * * * root /sbin/reboot" > /etc/cron.d/reboot
		echo "Auto Reboot VPS tiap 4 Jam" > /usr/bin/autoreboot.txt
		echo ""
		cat /usr/bin/autoreboot.txt
		echo ""
		
		exit
		;;
		5)
		rm /usr/bin/autoreboot.txt
		rm /etc/cron.d/reboot
		echo "0 */6 * * * root /sbin/reboot" > /etc/cron.d/reboot
		echo "Auto Reboot VPS tiap 6 Jam" > /usr/bin/autoreboot.txt
		echo ""
		cat /usr/bin/autoreboot.txt
		echo ""
		
		exit
		;;
		6)
		rm /usr/bin/autoreboot.txt
		rm /etc/cron.d/reboot
		echo "0 */8 * * * root /sbin/reboot" > /etc/cron.d/reboot
		echo "Auto Reboot VPS tiap 8 Jam" > /usr/bin/autoreboot.txt
		echo ""
		cat /usr/bin/autoreboot.txt
		echo ""
		
		exit
		;;
		7)
		rm /usr/bin/autoreboot.txt
		rm /etc/cron.d/reboot
		echo "0 */12 * * * root /sbin/reboot" > /etc/cron.d/reboot
		echo "Auto Reboot VPS tiap 12 Jam" > /usr/bin/autoreboot.txt
		echo ""
		cat /usr/bin/autoreboot.txt
		echo ""
		
		exit
		;;
		8)
		rm /usr/bin/autoreboot.txt
		rm /etc/cron.d/reboot
		echo "0 0 * * * root /sbin/reboot" > /etc/cron.d/reboot
		echo "Auto Reboot VPS tiap 1 Hari" > /usr/bin/autoreboot.txt
		echo ""
		cat /usr/bin/autoreboot.txt
		echo ""
		
		exit
		;;
		9)
		rm /usr/bin/autoreboot.txt
		rm /etc/cron.d/reboot
		echo "0 0 */2 * * root /sbin/reboot" > /etc/cron.d/reboot
		echo "Auto Reboot VPS tiap 2 Hari" > /usr/bin/autoreboot.txt
		echo ""
		cat /usr/bin/autoreboot.txt
		echo ""
		
		exit
		;;
		10)
		rm /usr/bin/autoreboot.txt
		rm /etc/cron.d/reboot
		echo "0 0 */7 * * root /sbin/reboot" > /etc/cron.d/reboot
		echo "Auto Reboot VPS tiap 7 Hari" > /usr/bin/autoreboot.txt
		echo ""
		cat /usr/bin/autoreboot.txt
		echo ""
		
		exit
		;;
		11)
		rm /usr/bin/autoreboot.txt
		rm /etc/cron.d/reboot
		echo "0 0 */14 * * root /sbin/reboot" > /etc/cron.d/reboot
		echo "Auto Reboot VPS tiap 14 Hari" > /usr/bin/autoreboot.txt
		echo ""
		cat /usr/bin/autoreboot.txt
		echo ""
		
		exit
		;;
		12)
		rm /usr/bin/autoreboot.txt
		rm /etc/cron.d/reboot
		echo "0 0 */30 * * root /sbin/reboot" > /etc/cron.d/reboot
		echo "Auto Reboot VPS tiap 30 Hari" > /usr/bin/autoreboot.txt
		echo ""
		cat /usr/bin/autoreboot.txt
		echo ""
		
		exit
		;;
		13)
		rm /usr/bin/autoreboot.txt
		rm /etc/cron.d/reboot
		echo "Auto Reboot NONAKTIF" > /usr/bin/autoreboot.txt
		echo ""
		cat /usr/bin/autoreboot.txt
		echo ""
		
		exit
		;;
		14)
		echo ""
		cat /usr/bin/autoreboot.txt
		echo ""
		
		exit
		;;
		x)
		cd /root
		
		exit
		;;
	esac
done