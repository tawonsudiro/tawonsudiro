#!/bin/bash
if [ $1 ]; then
	port_dropbear=$1
	log=/var/log/auth.log
	loginsukses='Password auth succeeded'
clear
	echo ' '
	echo "---------------------------------------------------------------" | lolcat -F 0.3
	echo "               Dropbear Users Login Monitor                    " | lolcat -F 0.3
	echo "---------------------------------------------------------------" | lolcat -F 0.3
	echo "    Date-time    |  PID      |  User Name      |     Host      " | lolcat -F 0.3
	echo "---------------------------------------------------------------" | lolcat -F 0.3
	pids=`ps ax |grep dropbear |grep  " $port_dropbear" |awk -F" " '{print $1}'`
	for pid in $pids
	do
		pidlogs=`grep $pid $log |grep "$loginsukses" |awk -F" " '{print $3}'`
		i=0
		for pidend in $pidlogs
		do
			let i=i+1
		done
		
		if [ $pidend ]; then
			login=`grep $pid $log |grep "$pidend" |grep "$loginsukses"`
			PID=$pid
			user=`echo $login |awk -F" " '{print $10}' | sed -r "s/'/ /g"`
			waktu=`echo $login |awk -F" " '{print $2,$3}'`
			while [ ${#waktu} -lt 13 ]
			do
				waktu=$waktu" "
			done
			
			while [ ${#user} -lt 16 ]
			do
				user=$user" "
			done
			
			while [ ${#PID} -lt 8 ]
			do
				PID=$PID" "
			done

			fromip=`echo $login |awk -F" " '{print $12}' |awk -F":" '{print $1}'`
			echo "  $waktu|  $PID | $user|  $fromip " | lolcat -F 0.3
		fi
	done
	
	echo "===============================================================" | lolcat -F 0.3
	echo " Kill User Ketik kill -9 (angka PID)" | lolcat -F 0.3
	echo " Contoh: kill -9 1234 [enter]" | lolcat -F 0.3
	echo -e "=========( DROPBEAR MONITOR )==========="| boxes -d dog| lolcat -F 0.2
echo -e "   ========================================" | lolcat -F 0.2
echo -e "          SCRIPT MODD BY TAWONSUDIRO       " | lolcat -F 0.2
echo -e "   WhatsApp Kami  : +6283148123457         " | lolcat -F 0.2
echo -e "   FB Group       : GKNIGHT REBORN SSH     " | lolcat -F 0.2
echo -e "   ========================================" | lolcat -F 0.2
echo -e "   YOUTUBE CHANNEL: GKNIGHT GG             " | lolcat -F 0.2
echo -e "                  : GKNIGHT REBORN         " | lolcat -F 0.2
echo -e "   ========================================" | lolcat -F 0.2
else
	echo "  Gunakan perintah ./dropmon [port]"
	echo "  Contoh : ./dropmon 443"
	echo ""
fi

exit 0