#!/bin/bash
clear
	echo -e "===========( USER EXPIRE )=============="    | boxes -d dog| lolcat -F 0.2
	echo -e "   ========================================" | lolcat -F 0.2
	echo -e "          SCRIPT MODD BY TAWONSUDIRO       " | lolcat -F 0.2
	echo -e "   WhatsApp Kami  : +6283148123457         " | lolcat -F 0.2
	echo -e "   FB Group       : GKNIGHT REBORN SSH     " | lolcat -F 0.2
	echo -e "   ========================================" | lolcat -F 0.2
	echo -e "   YOUTUBE CHANNEL: GKNIGHT GG             " | lolcat -F 0.2
	echo -e "                  : GKNIGHT REBORN         " | lolcat -F 0.2
	echo -e "   ========================================" | lolcat -F 0.2

disableexpire
clear

cat /root/expireduser.txt | lolcat -F 0.2