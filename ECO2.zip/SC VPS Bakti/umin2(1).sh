#!/bin/bash

if [[ $USER != 'root' ]]; then
	echo "Maaf, Anda harus menjalankan ini sebagai root"
	exit
fi

MYIP=$(wget -qO- ipv4.icanhazip.com)

vps="vpsuniq";

if [[ $vps = "vpsuniq" ]]; then
	source="masbakti.ml"
else
	source="masbakti.ml"
fi

# go to root
cd

# check registered ip
wget -q -O IP $source/IP.txt
if ! grep -w -q $MYIP IP; then
	echo "Hanya IP yang Terdaftar Saja !!!"
	if [[ $vps = "vpsuniq" ]]; then
		echo "Silahkan Hubungi BaBaNET >> WA : 085790808469 | BBM : D7FD3D6F"
	else
		echo "Silahkan Hubungi BaBaNET >> WA : 085790808469 | BBM : D7FD3D6F"
	fi
	rm -f /root/IP
	exit
fi

rm -rf /usr/binn
mkdir /usr/binn

clear

	cname=$( awk -F: '/model name/ {name=$2} END {print name}' /proc/cpuinfo )
	cores=$( awk -F: '/model name/ {core++} END {print core}' /proc/cpuinfo )
	freq=$( awk -F: ' /cpu MHz/ {freq=$2} END {print freq}' /proc/cpuinfo )
	tram=$( free -m | awk 'NR==2 {print $2}' )
	swap=$( free -m | awk 'NR==4 {print $2}' )
	opsy=$( cat /etc/issue.net | awk 'NR==1 {print}' )
    arch=$( uname -m )
    lbit=$( getconf LONG_BIT )
	up=$(uptime|awk '{ $1=$2=$(NF-6)=$(NF-5)=$(NF-4)=$(NF-3)=$(NF-2)=$(NF-1)=$NF=""; print }')
	date=$( date '+%A, %d %B %Y' )

	echo -e "+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+" | lolcat -F 0.2
	echo -e "+                               SELAMAT DATANG                                +" | lolcat -F 0.2
	echo -e "+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+" | lolcat -F 0.2
	echo -e "+                                                                             +" | lolcat -F 0.2
	echo -e "+                     Premium Script Modified by BaBaNET                      +"  | lolcat -F 0.2
	echo -e "+             Contact Us >> WA : +6285790808469 or BBM : D7FD3D6F             +" | lolcat -F 0.2
	echo -e "+                                                                             +" | lolcat -F 0.2
	echo -e "+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+" | lolcat -F 0.2
	echo -e ""
	echo -e "                             Informasi Server Anda                             " | lolcat -F 0.2
	echo -e "                             ---------------------                                "  | lolcat -F 0.2
	echo -e " IP/Host   :  $MYIP" | lolcat -F 0.2
	echo -e " CPU Model : $cname"  | lolcat -F 0.2
	echo -e " CPU Core  :  $cores"  | lolcat -F 0.2
	echo -e " Memory    :  $tram MB" | lolcat -F 0.2
	echo -e " Swap      :  $swap MB"  | lolcat -F 0.2
	echo -e " Uptime    : $up" | lolcat -F 0.2
	echo -e " Date      :  $date" | lolcat -F 0.2
	echo -e "===============================================================================" | lolcat -F 0.2
	echo -e "                       >>>>>>>>>> Menu Premium <<<<<<<<<<                      " | lolcat -F 0.2
	echo -e "===============================================================================" | lolcat -F 0.2
	echo -e ""
	echo -e "  1. Buat Akun SSH                      |     17. Cek Penggunaan Data by User" | lolcat -F 0.2
	echo -e "  2. Buat Akun SSH Trial                |     18. Ubah Port OpenSSH" | lolcat -F 0.2
	echo -e "  3. Tambah Masa Aktif Akun SSH         |     19. Ubah Port Dropbear" | lolcat -F 0.2
	echo -e "  4. Hapus Akun SSH                     |     20. Ubah Port Squid" | lolcat -F 0.2
	echo -e "  5. Ganti Password Akun SSH            |     21. Ubah Port OpenVPN" | lolcat -F 0.2
	echo -e "  6. Banned Akun SSH                    |     22. Ubah Banner Login" | lolcat -F 0.2
	echo -e "  7. Unbanned Akun SSH                  |     23. Cek Penggunaan Memory Server" | lolcat -F 0.2
	echo -e "  8. Monitoring Login Dropbear          |     24. Test Kecepatan Server" | lolcat -F 0.2
	echo -e "  9. Cek Login Akun SSH                 |     25. Ganti Password Server" | lolcat -F 0.2
	echo -e " 10. Daftar Akun SSH                    |     26. Menu Restart" | lolcat -F 0.2
	echo -e " 11. Daftar Akun SSH Aktif              |     27. Bersihkan Cache Ram" | lolcat -F 0.2
	echo -e " 12. Daftar Akun SSH Expire             |     28. Menu Blokir" | lolcat -F 0.2
	echo -e " 13. Hapus Akun SSH Expire              |     29. Menu Auto Reboot VPS" | lolcat -F 0.2
	echo -e " 14. Limit Login User SSH (1-3)         |" | lolcat -F 0.2
	echo -e " 15. Autokill user SSH Nakal            |" | lolcat -F 0.2
	echo -e " 16. Cek Lokasi IP User SSH Login" | lolcat -F 0.2
	echo -e ""
	echo -e " i >> Menu Instalasi" | lolcat -F 0.2
	echo -e " x >> Keluar"	 | lolcat -F 0.2
	echo -e ""
	read -p "Masukkan pilihan anda, kemudian tekan tombol ENTER : " option1
	echo ""
	case $option1 in
		1)
		wget -qcO /usr/binn/usernew $source/Debian7/usernew.sh && chmod +x /usr/binn/usernew && cd /usr/binn/ && ./usernew
		rm -rf /usr/binn/
		exit
		;;
		2)
		wget -qcO /usr/binn/usergen $source/Debian7/usergen.sh && chmod +x /usr/binn/usergen && cd /usr/binn/ && ./usergen
		rm -rf /usr/binn/
		exit
		;;
		3)
		wget -qcO /usr/binn/renew $source/Debian7/renew.sh && chmod +x /usr/binn/renew && cd /usr/binn/ && ./renew
		rm -rf /usr/binn/
		exit
		;;
		4)
		wget -qcO /usr/binn/hapus $source/Debian7/hapus.sh && chmod +x /usr/binn/hapus && cd /usr/binn/ && ./hapus
		rm -rf /usr/binn/
		exit
		;;
		5)
		wget -qcO /usr/binn/userpass $source/Debian7/userpass.sh && chmod +x /usr/binn/userpass && cd /usr/binn/ && ./userpass
		rm -rf /usr/binn/
		exit
		;;
		6)
		wget -qcO /usr/binn/banned $source/Debian7/banned.sh && chmod +x /usr/binn/banned && cd /usr/binn/
		./banned
		rm -rf /usr/binn/
		exit
		;;
		7)
		wget -qcO /usr/binn/unbanned $source/Debian7/unbanned.sh && chmod +x /usr/binn/unbanned && cd /usr/binn/
		./unbanned
		rm -rf /usr/binn/
		exit
		;;
		8)
		wget -qcO /usr/binn/dropmon $source/Debian7/dropmon.sh && chmod +x /usr/binn/dropmon && cd /usr/binn/
		read -p "Isikan Port Dropbear : " PORT
		./dropmon $PORT
		rm -rf /usr/binn/
		exit
		;;
		9)
		wget -qcO /usr/binn/userlogin $source/Debian7/userlogin.sh && chmod +x /usr/binn/userlogin && cd /usr/binn/
		./userlogin
		rm -rf /usr/binn/
		exit
		;;
		10)
		wget -qcO /usr/binn/userlist $source/Debian7/userlist.sh && chmod +x /usr/binn/userlist && cd /usr/binn/
		./userlist
		rm -rf /usr/binn/
		exit
		;;
		11)
		wget -qcO /usr/binn/useraktif $source/Debian7/useraktif.sh && chmod +x /usr/binn/useraktif && cd /usr/binn/
		./useraktif
		rm -rf /usr/binn/
		exit
		;;
		12)
		wget -qcO /usr/binn/userexpire $source/Debian7/userexpire.sh && chmod +x /usr/binn/userexpire && cd /usr/binn/
		./userexpire
		rm -rf /usr/binn/
		exit
		;;
		13)
		wget -qcO /usr/binn/deleteexpire $source/Debian7/deleteexpire.sh && chmod +x /usr/binn/deleteexpire && cd /usr/binn/
		./deleteexpire
		rm -rf /usr/binn/
		exit
		;;
		14)
		wget -qcO /usr/binn/userlimit $source/Debian7/userlimit.sh && chmod +x /usr/binn/userlimit && cd /usr/binn/		
		read -p "Isikan Maksimal Login (1,2,3) : " MULTILOGIN
		./userlimit $MULTILOGIN
		rm -rf /usr/binn/
		exit
		;;
		15)
		wget -qcO /usr/binn/autokill $source/Debian7/autokill.sh && chmod +x /usr/binn/autokill && cd /usr/binn/
		read -p "Isikan jumlah limit login yang dikehendaki (0,2,3) : " AUTOKILL
		./autokill $AUTOKILL
		rm -rf /usr/binn/
		exit
		;;
		16)
		wget -qcO /usr/binn/dropmon $source/Debian7/dropmon.sh && chmod +x /usr/binn/dropmon && cd /usr/binn/
		read -p "Isikan Port Dropbear yang ingin dicek terlebih dahulu : " PORT
		./dropmon $PORT
		read -p "Masukkan alamat IP yang ingin dicek lokasinya : " IPCEK
		curl ipinfo.io/$IPCEK
		rm -rf /usr/binn/
		exit
		;;
		17)
		vnstat --days
		rm -rf /usr/binn/
		exit
		;;
		18)
		wget -qcO /usr/binn/portopenssh $source/Debian7/portopenssh.sh && chmod +x /usr/binn/portopenssh && cd /usr/binn/ && ./portopenssh
		rm -rf /usr/binn/
		exit
		;;
		19)
		wget -qcO /usr/binn/portdropbear $source/Debian7/portdropbear.sh && chmod +x /usr/binn/portdropbear && cd /usr/binn/ && ./portdropbear
		rm -rf /usr/binn/
		exit
		;;
		20)
		wget -qcO /usr/binn/portsquid $source/Debian7/portsquid.sh && chmod +x /usr/binn/portsquid && cd /usr/binn/ && ./portsquid
		rm -rf /usr/binn/
		exit
		;;
		21)
		wget -qcO /usr/binn/portopenvpn $source/Debian7/portopenvpn.sh && chmod +x /usr/binn/portopenvpn && cd /usr/binn/ && ./portopenvpn
		rm -rf /usr/binn/
		exit
		;;
		22)
		wget -qcO /usr/binn/banner $source/Debian7/banner.sh && chmod +x /usr/binn/banner && cd /usr/binn/ && ./banner
		rm -rf /usr/binn/
		exit
		;;
		23)
		ps-mem
		rm -rf /usr/binn/
		exit
		;;
		24)
		speedtest --share
		rm -rf /usr/binn/
		exit
		;;
		25)
		passwd
		rm -rf /usr/binn/
		exit
		;;
		26)
		wget -qcO /usr/binn/mr $source/Debian7/menurestart.sh && chmod +x /usr/binn/mr && cd /usr/binn/ && ./mr
		rm -rf /usr/binn/
		exit
		;;
		27)
		wget -qcO /usr/binn/cc $source/Debian7/clearcache.sh && chmod +x /usr/binn/cc && cd /usr/binn/ && ./cc
		rm -rf /usr/binn/
		exit
		;;
		28)
		wget -qcO /usr/binn/mb $source/Debian7/menublokir.sh && chmod +x /usr/binn/mb && cd /usr/binn/ && ./mb
		rm -rf /usr/binn/
		exit
		;;
		29)
		wget -qcO /usr/binn/mrb $source/Debian7/reboot.sh && chmod +x /usr/binn/mrb && cd /usr/binn/ && ./mrb
		rm -rf /usr/binn/
		exit
		;;
		i)
		wget -qcO /usr/binn/mi $source/Debian7/menuinstalasi.sh && chmod +x /usr/binn/mi && cd /usr/binn/ && ./mi
		rm -rf /usr/binn/
		exit
		;;
		x)
		rm /root/IP
		rm -rf /usr/binn/
		exit
		;;
	esac
done

cd
rm -f /root/IP
