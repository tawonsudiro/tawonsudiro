#!/bin/bash
clear

myip=`ifconfig | grep -Eo 'inet (addr:)?([0-9]*\.){3}[0-9]*' | grep -Eo '([0-9]*\.){3}[0-9]*' | grep -v '127.0.0' | head -n1`;

flag=0

echo

function create_user() {
#myip=`dig +short myip.opendns.com @resolver1.opendns.com`
clear
echo -e ""| lolcat
echo -e ""| lolcat
echo -e ""| lolcat
echo -e ""| lolcat
useradd -e `date -d "$masaaktif days" +"%Y-%m-%d"` -s /bin/false -M $uname
exp="$(chage -l $uname | grep "Account expires" | awk -F": " '{print $2}')"
echo -e "$pass\n$pass\n"|passwd $uname &> /dev/null
echo -e ""| lolcat
echo -e "|      Informasi Akun Baru SSH      |" | boxes -d mouse| lolcat
echo -e "============-Tawonsudiro-================" | lolcat
echo -e "     Host: $myip                         " | lolcat
echo -e "     Username: $uname                    " | lolcat
echo -e "     Password: $pass                     " | lolcat
echo -e "     Port dropbear: 443,109              " | lolcat
echo -e "     Port openSSH: 22,80                 " | lolcat
echo -e "     Port squid: 8080                    " | lolcat
echo -e "     Port OpenVPN default: 55            " | lolcat
echo -e "     Auto kill user maximal login 2      " | lolcat
echo -e "-------------------------------------------" | lolcat
echo -e "     Aktif Sampai: $exp                  " | lolcat
echo -e "===========================================" | lolcat
echo -e "   DI LARANG:                            "| lolcat
echo -e "   HACKING-DDOS-PHISING-SPAM-TORENT      "| lolcat
echo -e "   CARDING-CRIMINAL CYBER.               "| lolcat
echo -e "==========================================="| lolcat
echo -e "Script Modified By.Tawonsudiro        "| lolcat
myip=`ifconfig | grep -Eo 'inet (addr:)?([0-9]*\.){3}[0-9]*' | grep -Eo '([0-9]*\.){3}[0-9]*' | grep -v '127.0.0' | head -n1`;
echo -e "   Config OVPN:                          "| lolcat
echo -e "   http://$myip:8090/client.tar          "| lolcat
echo -e "-------------------------------------------"| lolcat
echo -e ""| lolcat
echo -e ""| lolcat
}
function perpanjang-user() {
#!/bin/bash
#Script Perpanjang User SSH

read -p "Username : " Login
read -p "Password Baru : " Pass
read -p "Penambahan Masa Aktif (hari): " masaaktif
userdel $Login
useradd -e `date -d "$masaaktif days" +"%Y-%m-%d"` -s /bin/false -M $Login
exp="$(chage -l $Login | grep "Account expires" | awk -F": " '{print $2}')"
echo -e "$Pass\n$Pass\n"|passwd $Login &> /dev/null

echo -e "Akun Sudah Diperpanjang Hingga $exp"| lolcat
Password telah diganti dengan $Pass"| lolcat
Script Modified By.Tawonsudiro" | boxes -d boy| lolcat
}
function renew_user() {
	echo "Kadaluarsa User: $uname Di Perbarui Sampai: $expdate";
	usermod -e $expdate $uname
}

function delete_user(){
	userdel $uname
}
function info_vps(){
#!/bin/bash
#
echo "---------------------------------Setup Server ----------------------------------"
echo "                           Copyright GKnight Reborn                             "
echo "                          Modified By GKnight Reborn                            "
echo "--------------------------------------------------------------------------------"
echo ""  | tee -a log-install.txt
echo "Informasi Server"  | tee -a log-install.txt
echo "   - IP Server   : $myip"
echo "   - Timezone    : Asia/Jakarta (GMT +7)"  | tee -a log-install.txt
echo "   - Fail2Ban    : [on]"  | tee -a log-install.txt
echo "   - IPtables    : [on]"  | tee -a log-install.txt
echo "   - Auto-Reboot : [off]"  | tee -a log-install.txt
echo "   - IPv6        : [off]"  | tee -a log-install.txt
echo ""  | tee -a log-install.txt
echo "Informasi Aplikasi & Port"  | tee -a log-install.txt
echo "   - OpenVPN     : TCP 1194 "  | tee -a log-install.txt
echo "   - OpenSSH     : 22, 143"  | tee -a log-install.txt
echo "   - Dropbear    : 109, 110, 443"  | tee -a log-install.txt
echo "   - Squid Proxy : 80, 3128, 8000, 8080 (limit to IP Server)"  | tee -a log-install.txt
echo "   - Badvpn      : 7300"  | tee -a log-install.txt
echo "   - Nginx       : 85"  | tee -a log-install.txt
echo "   - PPTP VPN    : 1732"  | tee -a log-install.txt
echo ""  | tee -a log-install.txt
echo "Informasi Tools Dalam Server"  | tee -a log-install.txt
echo "   - htop"  | tee -a log-install.txt
echo "   - iftop"  | tee -a log-install.txt
echo "   - mtr"  | tee -a log-install.txt
echo "   - nethogs"  | tee -a log-install.txt
echo "   - screenfetch"  | tee -a log-install.txt
echo ""  | tee -a log-install.txt
echo "Informasi Premium Script"  | tee -a log-install.txt
echo "   Perintah untuk menampilkan daftar perintah: menu"  | tee -a log-install.txt
echo ""  | tee -a log-install.txt
echo "   Penjelasan script dan setup VPS"| tee -a log-install.txt
echo "   dapat dilihat di: http://bit.ly/penjelasansetup"  | tee -a log-install.txt
echo ""  | tee -a log-install.txt
echo "Informasi Penting"  | tee -a log-install.txt
echo "   - Download Config OpenVPN : http://$myip:85/client.ovpn"  | tee -a log-install.txt
echo "     Mirror (*.tar.gz)       : http://$myip:85/openvpn.tar.gz"  | tee -a log-install.txt
echo "   - Webmin                  : http://$myip:10000/"  | tee -a log-install.txt
echo "   - Vnstat                  : http://$myip:85/vnstat/"  | tee -a log-install.txt
echo "   - MRTG                    : http://$myip:85/mrtg/"  | tee -a log-install.txt
echo "   - Log Instalasi           : cat /root/log-install.txt"  | tee -a log-install.txt
echo "     NB: User & Password Webmin adalah sama dengan user & password root"  | tee -a log-install.txt
echo ""  | tee -a log-install.txt
echo "----------- Script  Modified Tawonsudiro------------"
}
function change_hostname(){
#!/bin/bash

# Assign current hostname to $oldhost
oldhost=$(cat /etc/hostname)

# Display current hostname
echo "Hostname Lama Anda : $oldhost" |lolcat

# Make backup of current files
sudo cp /etc/hostname /etc/hostname.bak
sudo cp /etc/hosts /etc/hosts.bak

# Ask for new hostname $newhost
read -p "Masukan Hostname Baru: " newhost 

# Change hostname in /etc/hostname & /etc/hosts (the first two edit the files in place)
# sudo sed -i "s/$oldhost/$newhost/g" /etc/hostname
# sudo sed -i "s/$oldhost/$newhost/g" /etc/hosts
cat /etc/hostname | sed "s/$oldhost/$newhost/g" > ./hostname.tmp
cat /etc/hosts | sed "s/$oldhost/$newhost/g" > ./hosts.tmp

# Move new files to /etc/hostname & /etc/hosts
sudo mv ./hostname.tmp /etc/hostname
sudo mv ./hosts.tmp /etc/hosts

echo "Hostname Telah Diganti Menjadi $newhost"
read -s -n 1 -p "Pencet Sembarang Tombol Untuk Mereboot" |lolcat
sudo reboot
}

function expired_users(){
echo "                      _\|/_      "| lolcat
echo "                      (o o)      "| lolcat
echo "-------------------o00-{_}-00o---"| lolcat
echo "BIL  USERNAME          EXPIRED "
echo "---------------------------------"| lolcat
count=1
	cat /etc/shadow | cut -d: -f1,8 | sed /:$/d > /tmp/expirelist.txt
	totalaccounts=`cat /tmp/expirelist.txt | wc -l`
	for((i=1; i<=$totalaccounts; i++ )); do
	tuserval=`head -n $i /tmp/expirelist.txt | tail -n 1`
		username=`echo $tuserval | cut -f1 -d:`
		userexp=`echo $tuserval | cut -f2 -d:`
		userexpireinseconds=$(( $userexp * 86400 ))
		todaystime=`date +%s`
		expired="$(chage -l $username | grep "Account expires" | awk -F": " '{print $2}')"
		if [ $userexpireinseconds -lt $todaystime ] ; then
			printf "%-4s %-15s %-10s %-3s\n" "$count." "$username" "$expired"
			count=$((count+1))
		fi
	done
	rm /tmp/expirelist.txt
}

function not_expired_users(){
    cat /etc/shadow | cut -d: -f1,8 | sed /:$/d > /tmp/expirelist.txt
    totalaccounts=`cat /tmp/expirelist.txt | wc -l`
    for((i=1; i<=$totalaccounts; i++ )); do
        tuserval=`head -n $i /tmp/expirelist.txt | tail -n 1`
        username=`echo $tuserval | cut -f1 -d:`
        userexp=`echo $tuserval | cut -f2 -d:`
        userexpireinseconds=$(( $userexp * 86400 ))
        todaystime=`date +%s`
        if [ $userexpireinseconds -gt $todaystime ] ; then
            echo $username
        fi
    done
	rm /tmp/expirelist.txt
}

function monssh2(){
echo ""
echo "|   Tgl-Jam    | PID   |   User Name  |      Dari IP      |"| boxes -d peek| lolcat
echo "-------------------------------------------------------------"| lolcat
data=( `ps aux | grep -i dropbear | awk '{print $2}'`);

echo "=================[ Checking Dropbear login ]================="| lolcat
echo "-------------------------------------------------------------"| lolcat
for PID in "${data[@]}"
do
	#echo "check $PID";
	NUM=`cat /var/log/auth.log | grep -i dropbear | grep -i "Password auth succeeded" | grep "dropbear\[$PID\]" | wc -l`;
	USER=`cat /var/log/auth.log | grep -i dropbear | grep -i "Password auth succeeded" | grep "dropbear\[$PID\]" | awk -F" " '{print $10}'`;
	IP=`cat /var/log/auth.log | grep -i dropbear | grep -i "Password auth succeeded" | grep "dropbear\[$PID\]" | awk -F" " '{print $12}'`;
	waktu=`cat /var/log/auth.log | grep -i dropbear | grep -i "Password auth succeeded" | grep "dropbear\[$PID\]" | awk -F" " '{print $1,$2,$3}'`;
	if [ $NUM -eq 1 ]; then
		echo "$waktu - $PID - $USER - $IP";
	fi
done
echo ""
echo "-------------------------------------------------------------"| lolcat
data=( `ps aux | grep "\[priv\]" | sort -k 72 | awk '{print $2}'`);
echo "==================[ Checking OpenSSH login ]================="| lolcat
echo "-------------------------------------------------------------"| lolcat
for PID in "${data[@]}"
do
        #echo "check $PID";
		NUM=`cat /var/log/auth.log | grep -i sshd | grep -i "Accepted password for" | grep "sshd\[$PID\]" | wc -l`;
		USER=`cat /var/log/auth.log | grep -i sshd | grep -i "Accepted password for" | grep "sshd\[$PID\]" | awk '{print $9}'`;
		IP=`cat /var/log/auth.log | grep -i sshd | grep -i "Accepted password for" | grep "sshd\[$PID\]" | awk '{print $11}'`;
		waktu=`cat /var/log/auth.log | grep -i sshd | grep -i "Accepted password for" | grep "sshd\[$PID\]" | awk '{print $1,$2,$3}'`;
        if [ $NUM -eq 1 ]; then
                echo "$waktu - $PID - $USER - $IP";
        fi
done

echo "-------------------------------------------------------------"| lolcat
echo -e "==============[ User Monitor Dropbear & OpenSSH]============="| lolcat
}

function used_data(){
	myip=`ifconfig | grep -Eo 'inet (addr:)?([0-9]*\.){3}[0-9]*' | grep -Eo '([0-9]*\.){3}[0-9]*' | grep -v '127.0.0' | head -n1`
	myint=`ifconfig | grep -B1 "inet addr:$myip" | head -n1 | awk '{print $1}'`
	ifconfig $myint | grep "RX bytes" | sed -e 's/ *RX [a-z:0-9]*/Received: /g' | sed -e 's/TX [a-z:0-9]*/\nTransfered: /g'
}

function bench-network2(){
wget freevps.us/downloads/bench.sh -O - -o /dev/null|bash
echo -e "Sekian...!!!"| lolcat
}

function user-list(){
echo "--------------------------------------------------"| lolcat
echo "BIL  USERNAME        STATUS       EXP DATE   "| lolcat
echo "--------------------------------------------------"| lolcat
C=1
ON=0
OFF=0
while read mumetndase
do
        USER="$(echo $mumetndase | cut -d: -f1)"
        ID="$(echo $mumetndase | grep -v nobody | cut -d: -f3)"
        EXP="$(chage -l $USER | grep "Account expires" | awk -F": " '{print $2}')"
        if [[ $ID -ge 500 ]]; then
        if [[ -z $ONLINE ]]; then
        printf "%-4s %-15s %-10s %-3s\n" "$C." "$USER" "OFFLINE" "$EXP"
        OFF=$((OFF+1))
        else
        printf "%-4s %-15s %-10s %-3s\n" "$C." "$USER" "ONLINE" "$EXP"
        ON=$((ON+1))
        fi
        C=$((C+1))
        fi
JUMLAH="$(awk -F: '$3 >= 1000 && $1 != "nobody" {print $1}' /etc/passwd | wc -l)"
done < /etc/passwd
echo "--------------------------------------------------"| lolcat
echo " ONLINE : $ON     OFFLINE : $OFF     TOTAL USER : $JUMLAH "| lolcat
echo "--------------------------------------------------"| lolcat
}

function lokasi(){

data=( `ps aux | grep -i dropbear | awk '{print $2}'`);

echo "User Login" | boxes -d peek | lolcat;
echo "=================================";
echo "Dropbear" | lolcat
for PID in "${data[@]}"
do
    #echo "check $PID";
    NUM=`cat /var/log/auth.log | grep -i dropbear | grep -i "Password auth succeeded" | grep "dropbear\[$PID\]" | wc -l`;
    USER=`cat /var/log/auth.log | grep -i dropbear | grep -i "Password auth succeeded" | grep "dropbear\[$PID\]" | awk '{print $10}'`;
    IP=`cat /var/log/auth.log | grep -i dropbear | grep -i "Password auth succeeded" | grep "dropbear\[$PID\]" | awk '{print $12}'`;
    if [ $NUM -eq 1 ]; then
        echo "$USER - $IP";
    fi
done
echo ""
echo "OpenSSH" | lolcat;

data=( `ps aux | grep "\[priv\]" | sort -k 72 | awk '{print $2}'`);


for PID in "${data[@]}"
do
        #echo "check $PID";
        NUM=`cat /var/log/auth.log | grep -i sshd | grep -i "Accepted password for" | grep "sshd\[$PID\]" | wc -l`;
        USER=`cat /var/log/auth.log | grep -i sshd | grep -i "Accepted password for" | grep "sshd\[$PID\]" | awk '{print $9}'`;
        IP=`cat /var/log/auth.log | grep -i sshd | grep -i "Accepted password for" | grep "sshd\[$PID\]" | awk '{print $11}'`;
        if [ $NUM -eq 1 ]; then
                echo "$USER - $IP";
        fi
done
echo "-------------------------------" | lolcat
}
clear
echo "" | lolcat
echo "" 
echo "        ---[MODIFIED SCRIPT BY. Tawonsudiro]---"| boxes -d mouse| lolcat
echo "        ====================================================="| lolcat
echo "        #           WhatsApp     : 083148123457             #"| lolcat
echo "        #           Facebook     : SumbonGknightReborn      #"| lolcat
echo "        #           Pin-BBM      : Gknight                  #"| lolcat
echo "        #              GKnight Reborn Team                  #"| lolcat
echo "        #         Copyright © Tawonsudiro                   #"| lolcat
echo "        ====================================================="| lolcat
echo "              Your Ip Adress : $myip"| lolcat
echo "-------------------------------------------------------------------" |lolcat
echo "--------------- Welcome to Premium Script Menu -------------" |lolcat
	
echo "-------------------Silahkan Request Fitur Lain---------------------" |lolcat
echo "---------------Script Modified Tawonsudiro-----------------" |lolcat
 PS3='-------------------------------------------------------------------
Silahkan ketik nomor pilihan anda lalu tekan ENTER: '
options=(
"Buat Akun" 
"Membuat User Trial SSH & VPN" 
"Perbaharui User SSH"
"Melihat Semua User SSH & VPN" 
"Ganti Password SSH"
"Perpanjang SSH"
"Menghapus User SSH & VPN"
"Melihat User Login SSH & VPN"
"Mengaktifkan Kill Multi Login"
"Menonaktifkan Kill Multi Login"
"Lihat User Kadaluarsa"
"Lihat User Wis Kadaluarsa"
"Lihat Lokasi User"
"Penggunaan Data User"
"Mengganti Server Massage"
"Mengganti Port VPS"
"Melihat bench-network" 
"Melihat Statut RAM"
"Membersihkan Cache RAM"
"Melihat Speed VPS" 
"Merestart All Fitur VPS"
"Mereboot  VPS"
"Seputar Auto Reboot VPS"
"Mengganti Password VPS" 
"Mengganti Hostname VPS"
"Melihat Info Instalasi VPS"
"Kembali Ke Tampilan Awal") 
select opt in "${options[@]}"
do
    case $opt in
        "Buat Akun")
       read -p "Enter username: " uname
       read -p "Enter password: " pass
       read -p "Kadaluarsa (Berapa Hari): " masaaktif
       clear
       create_user
	    break
            ;;
	    "Melihat Info Instalasi VPS")
	   info_vps |lolcat
	       break
            ;;
	    "Mengganti Hostname VPS")
	     change_hostname | boxes -d mouse| lolcat
	     break
          ;;
	"Membuat User Trial SSH & VPN")
	uname=trial-`</dev/urandom tr -dc X-Z0-9 | head -c4`
	masaaktif="1"
	pass=`</dev/urandom tr -dc a-f0-9 | head -c9`
	clear
	create_user
	break
	;;
        "Perbaharui User SSH")
            user-list | boxes -d mouse| lolcat
            read -p "Enter username yg di perbarui: " uname
            read -p "Aktif sampai tanggal Thn-Bln-Hr(YYYY-MM-DD): " expdate
            renew_user | boxes -d boy| lolcat
            break
            ;;
	 "Melihat Semua User SSH & VPN")
	    user-list | boxes -d mouse| lolcat
	    break
	    ;;
	    "Perpanjang SSH")
	    perpanjang-user | boxes -d mouse |lolcat
	     break
	    ;;
        "Menghapus User SSH & VPN")
            user-list | boxes -d mouse| lolcat
            read -p "Ketik user yang akan di hapus: " uname
            delete_user
            echo -e "User $uname berhasil di hapus" | boxes -d boy| lolcat
	    break
            ;;
	  "Melihat User Login SSH & VPN")
	  monssh2
	  break
	  ;;
	    "Mengaktifkan Kill Multi Login")
	   echo "* * * * * root ./userlimit 2" > /etc/cron.d/userlimit1
	   echo "* * * * * root sleep 10; ./userlimit.sh 2" > /etc/cron.d/userlimit2
           echo "* * * * * root sleep 20; ./userlimit.sh 2" > /etc/cron.d/userlimit3
           echo "* * * * * root sleep 30; ./userlimit.sh 2" > /etc/cron.d/userlimit4
           echo "* * * * * root sleep 40; ./userlimit.sh 2" > /etc/cron.d/userlimit5
           echo "* * * * * root sleep 50; ./userlimit.sh 2" > /etc/cron.d/userlimit6
	    service cron restart
	    service ssh restart
	    service dropbear restart
	    echo "AUTO KILL 2 LOGIN SUDAH DI AKTIFKAN, USER MULTILOGIN OTOMATIS LOGOUT"
	    
	echo "SCRIPT AUTOKILL BERHASIL DIAKTIFKAN " | boxes -d boy| lolcat
		break
		;;
	"Menonaktifkan Kill Multi Login")
	rm -rf /etc/cron.d/userlimit1
	rm -rf /etc/cron.d/userlimit2
	rm -rf /etc/cron.d/userlimit3
	rm -rf /etc/cron.d/userlimit4
	rm -rf /etc/cron.d/userlimit5
	rm -rf /etc/cron.d/userlimit6
	service cron restart
	    service ssh restart
	    service dropbear restart
	echo "AUTO KILL BERHASIL DIMATIKAN" | boxes -d boy| lolcat
	break
	;;
		"Lihat User Kadaluarsa")
			not_expired_users | boxes -d mouse| lolcat
			break
			;;
			
			"Lihat User Wis Kadaluarsa")
			expired_users | boxes -d mouse| lolcat
			break
			;;		
		"Lihat Lokasi User")
			expired_users | boxes -d mouse| lolcat
			break
			;;		
		"Mereboot  VPS")
			reboot
			echo "VPSmu Berhasil Direboot" boxes -d boy | lolcat
			break
			;;
		"Ganti Password SSH")
		read -p "Ketik user yang akan di ganti passwordnya: " uname 
		read -p "Silahkan isi passwordnya: " pass 
		echo "$uname:$pass" | chpasswd | lolcat
		echo "SUKSES!!! Password $uname berhasil diganti"| boxes -d peek | lolcat
		break
		;;
		"Mengganti Password VPS")
		       passwd
		echo "Password VPS berhasi diganti"| boxes -d boy| lolcat
			break
			;;
		"Penggunaan Data User")
			used_data | boxes -d boy| lolcat
 			break
			;;
		"Melihat bench-network")
			bench-network2| lolcat
			break
			;;
		"Melihat Statut RAM")
			free -h | grep -v + > /tmp/ramcache
			cat /tmp/ramcache | grep -v "Swapfile"
			break
			;;
		"Membersihkan Cache RAM")
	                echo 3 > /proc/sys/vm/drop_caches && swapoff -a && swapon -a
			echo "SUKSES..!!!Cache ram anda sudah di bersihkan." | boxes -d spring| lolcat
		        break
			;;
		"Mengganti Server Massage")
	echo -e "1. Simpan text (CTRL + X, lalu ketik Y dan tekan Enter)
	2. Membatalkan edit text (CTRL + X, lalu ketik N dan tekan Enter)" | boxes -d boy | lolcat
	read -p "Tekan ENTER untuk melanjutkan........................ " | lolcat
	nano /bannerssh
	service ssh restart &&  service dropbear restart
	break
	;;
	"Merestart All Fitur VPS")
	               service nginx start
                       service php5-fpm start
                       service vnstat restart
                       service openvpn restart
                       service snmpd restart
                       service ssh restart
                       service dropbear restart
                       service fail2ban restart
                       service squid3 restart
                       service webmin restart
                       service pptpd restart
	       echo "-------Fitur Yang Telah Direstart-------"| boxes -d mouse| lolcat
	       echo "----------------------------------------"| lolcat
	       echo "#-Nginx                      -Php5-fpm #"| lolcat
	       echo "#-Vnstat                     -OpenVPN  #"| lolcat
	       echo "#-Snmpd                      -OpenSSH  #"| lolcat
	       echo "#-Dropbear                   -Fail2ban #"| lolcat
	       echo "#-Squid3                     -Webmin   #"| lolcat
	       echo "#              -Pptbpd                 #"| lolcat
	        echo "----------------------------------------"| lolcat
		       break
		       ;;
			"Melihat Speed VPS")
			python speedtest.py --share| lolcat
			break		
			;;
			"Lihat Lokasi User")
			 lokasi
                        read -p "Ketik Salah Satu Alamat IP User: " userip
                        curl ipinfo.io/$userip
                        break
                        ;;
			
			"Mengganti Port VPS")
			clear
                       editing-port
			break
			;;
			"Seputar Auto Reboot VPS")
			clear
                       auto-reboot
			break
			;;
		"Kembali Ke Tampilan Awal")
		screenfetch |lolcat
		break
		;;
	 
        *) echo invalid option;
	esac
	
done
