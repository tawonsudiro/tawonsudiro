#!/bin/bash

if [[ $USER != 'root' ]]; then
	echo "Maaf, Anda harus menjalankan ini sebagai root"
	exit
fi

MYIP=$(wget -qO- ipv4.icanhazip.com)

vps="enggih";

# go to root
cd

# check registered ip
wget -q -O IP $source/IP.txt
if ! grep -w -q $MYIP IP; then
	echo "Hanya IP yang Terdaftar Saja !!!"
	if [[ $vps = "enggih" ]]; then
		echo "enggih"
	else
		echo "engih"
	fi
	rm -f /root/IP
	exit
fi

clear
	echo -e "+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+" | lolcat -F 0.2
	echo -e "===============================================================================" | lolcat -F 0.2
	echo -e "                >>>>>>>>>> Clear Cache Memory Server <<<<<<<<<<                " | lolcat -F 0.2
	echo -e "===============================================================================" | lolcat -F 0.2
	echo ""

echo "Status Memory Sebelum dibersihkan" | lolcat -F 0.2
free -m
sync; echo 1 > /proc/sys/vm/drop_caches
echo ""
echo "Status Memory Sesudah dibersihkan" | lolcat -F 0.2
free -m

cd ~/
rm -f /root/IP
