#!/bin/bash

if [[ $USER != 'root' ]]; then
	echo "Maaf, Anda harus menjalankan ini sebagai root"
	exit
fi

MYIP=$(wget -qO- ipv4.icanhazip.com)

vps="vpsuniq";

if [[ $vps = "vpsuniq" ]]; then
	source="babanet.us/installer/"
else
	source="babanet.us/installer/"
fi

# go to root
cd

# check registered ip
wget -q -O IP $source/IP.txt
if ! grep -w -q $MYIP IP; then
	echo "Hanya IP yang Terdaftar Saja !!!"
	if [[ $vps = "vpsuniq" ]]; then
		echo "Silahkan Hubungi BaBaNET"
	else
		echo "Silahkan Hubungi BaBaNET"
	fi
	rm -f /root/IP
	exit
fi

rm -rf /usr/binn
mkdir /usr/binn

clear

	echo "Please Wait ................. " | lolcat -F 0.3
	wget -qcO /usr/binn/menu $source/Debian7/menu.sh && chmod +x /usr/binn/menu && cd /usr/binn/ && ./menu
	sleep 1
rm -rf /usr/binn
