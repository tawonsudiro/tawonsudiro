#!/bin/bash
if [[ $USER != 'root' ]]; then
	echo "Maaf, Anda harus menjalankan ini sebagai root"
	exit
fi

MYIP=$(wget -qO- ipv4.icanhazip.com)
clear
	echo -e "=========================(WELLCOME)========================"    | boxes -d sunset| lolcat -F 0.2
	echo -e "              SCRIPT MODIFIKASI BY TAWONSUDIRO       " | lolcat -F 0.2
	echo -e "==================================================================" | lolcat -F 0.2
	echo -e "              WhatsApp Kami       : +6283148123457         " | lolcat -F 0.2
	echo -e "              Facebook            : GKNIGHT REBORN SSH     " | lolcat -F 0.2
	echo -e "              YOUTUBE CHANNEL     : GKNIGHT GG             " | lolcat -F 0.2
	echo -e "                                  : GKNIGHT REBORN         " | lolcat -F 0.2
	echo -e "==================================================================" | lolcat -F 0.2
	echo -e "============================( MENU AKUN)=========================="| lolcat -F 0.2
	echo -e ""
	echo -e "  1. Buat SSH Trial"                | lolcat -F 0.2
	echo -e "  2. Buat AKUN SSH  "               | lolcat -F 0.2
	echo -e "  3. Hapus Akun SSH  "              | lolcat -F 0.2
	echo -e "  4. Tambah Masa Aktif SSH"         | lolcat -F 0.2
	echo -e "  5. Ganti Password Akun SSH"       | lolcat -F 0.2
	echo -e ""
	echo -e " X = Menu Utama"	 | lolcat -F 0.2
	echo -e ""
	read -p "Pilih dan  ENTER : " option1
	echo ""
	case $option1 in
		1)
		cd /root/baso/ && ./usergen.sh
		exit
		;;
		2)
		cd /root/baso/ && ./usernew.sh
		exit
		;;
		3)
		cd /root/baso/ && ./hapus.sh
		exit
		;;
		4)
		cd /root/baso/ && ./renew.sh
		exit
		;;
		5)
		cd /root/baso/ && ./userpass.sh
		exit
		;;
		x)
		cd /root &&./minil.sh
		;;
	esac
done
