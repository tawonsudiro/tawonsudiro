#!/bin/bash
clear
	echo -e "==========( MENU UNBANNED )============="    | boxes -d dog| lolcat -F 0.2
	echo -e "   ========================================" | lolcat -F 0.2
	echo -e "          SCRIPT MODD BY TAWONSUDIRO       " | lolcat -F 0.2
	echo -e "   WhatsApp Kami  : +6283148123457         " | lolcat -F 0.2
	echo -e "   FB Group       : GKNIGHT REBORN SSH     " | lolcat -F 0.2
	echo -e "   ========================================" | lolcat -F 0.2
	echo -e "   YOUTUBE CHANNEL: GKNIGHT GG             " | lolcat -F 0.2
	echo -e "                  : GKNIGHT REBORN         " | lolcat -F 0.2
	echo -e "   ========================================" | lolcat -F 0.2

# begin of user-list
echo "   ----------------------------------------" | lolcat -F 0.3
echo "  USERNAME              EXP DATE     " | lolcat -F 0.3
echo "   ----------------------------------------" | lolcat -F 0.3

while read expired
do
	AKUN="   $(echo $expired | cut -d: -f1)"
	ID="   $(echo $expired | grep -v nobody | cut -d: -f3)"
	exp="   $(chage -l $AKUN | grep "Account expires" | awk -F": " '{print $2}')"
	if [[ $ID -ge 1000 ]]; then
		printf "%-21s %2s\n" "$AKUN" "$exp" | lolcat -F 0.3
	fi
done < /etc/passwd
echo "----------------------------------------" | lolcat -F 0.3
echo ""
# end of user-list

read -p "Isikan username: " username

egrep "^$username" /etc/passwd >/dev/null
if [ $? -eq 0 ]; then
	echo ""
	read -p "Apakah Anda benar-benar ingin membuka blokir untuk akun [$username] [y/n]: " -e -i y UNBANNED
	if [[ "$UNBANNED" = 'y' ]]; then
		passwd -u $username
		echo ""
		echo "Akun [$username] berhasil dibuka blokirnya!" | lolcat -F 0.3
	else
		echo ""
		echo "Unbanned akun [$username] dibatalkan!" | lolcat -F 0.3
	fi
else
	echo "Username [$username] belum terdaftar!" | lolcat -F 0.3
	fi
	exit 1