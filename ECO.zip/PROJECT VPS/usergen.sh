#!/bin/bash
clear
	echo -e "===========(  TRIAL AKUN )=============="    | boxes -d dog| lolcat -F 0.2
	echo -e "   ========================================" | lolcat -F 0.2
	echo -e "          SCRIPT MODD BY TAWONSUDIRO       " | lolcat -F 0.2
	echo -e "   WhatsApp Kami  : +6283148123457         " | lolcat -F 0.2
	echo -e "   FB Group       : GKNIGHT REBORN SSH     " | lolcat -F 0.2
	echo -e "   ========================================" | lolcat -F 0.2
	echo -e "   YOUTUBE CHANNEL: GKNIGHT GG             " | lolcat -F 0.2
	echo -e "                  : GKNIGHT REBORN         " | lolcat -F 0.2
	echo -e "   ========================================" | lolcat -F 0.2

read -p "Jumlah Akun : " JUMLAH
read -p "Masa Aktif  : " AKTIF

today="$(date +"%Y-%m-%d")"
expire=$(date -d "$AKTIF days" +"%Y-%m-%d")

  echo ""
  echo "   ------------------------------------" | lolcat -F 0.3
  echo "               DATA SSH                " | lolcat -F 0.3
  echo "   ------------------------------------" | lolcat -F 0.3
  echo "     Host         : $MYIP" | lolcat -F 0.3
  echo "     Port Dropbear: 109, 110, 443" | lolcat -F 0.3
  echo "     Port OpenSSH : 143" | lolcat -F 0.3
  echo "     Squid Proxy  : 8080, 3128" | lolcat -F 0.3
for (( i=1; i <= $JUMLAH; i++ ))
do
	username=gknight-trial-`cat /dev/urandom | tr -dc '0-9' | fold -w 4 | head -n 1`;
	useradd -M -N -s /bin/false -e $expire $username
	#password=`cat /dev/urandom | tr -dc 'a-z0-9' | fold -w 8 | head -n 1`;
	echo $username:$username | chpasswd
	
	echo "  $i. Username/Password: $username" | lolcat -F 0.3
done
  echo "  Aktif s/d    : $(date -d "$AKTIF days" +"%d-%m-%Y")" | lolcat -F 0.3
  echo -e "   ===============================" | lolcat -F 0.2
	echo -e "            RULES KAMI            "  
	echo -e "  No DDOS,No CARDING,No SPAMMING "  
	echo -e "  No TORENT, dan NO CYBER CRIME  " 
	echo -e "           MAX LOGIN 2 APP        "  
	echo -e "  ===============================" | lolcat -F 0.2
	echo -e "  MELANGGAR RULES KAMI MAKA AKUN " 
	echo -e "       SECARA OTOMATIS DIBANNED   " 
	echo -e "   ===============================" | lolcat -F 0.2
	echo -e ""
	echo -e "  1. Menu Utama"                | lolcat -F 0.2
	echo -e "  2. Menu Akun  "               | lolcat -F 0.2
	read -p "Pilih dan  ENTER : " option1
	echo ""
	case $option1 in
		1)
		cd /root &&./minil.sh
		exit
		;;
		2)
		cd /root/baso/ && ./menuakun.sh
		exit
		;;
	esac
done