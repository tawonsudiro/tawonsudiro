#!/bin/bash

if [[ $USER != "root" ]]; then
	echo "Maaf, Anda harus menjalankan ini sebagai root"
	exit
fi

# initialisasi var
export DEBIAN_FRONTEND=noninteractive
OS=`uname -m`;
MYIP=$(wget -qO- ipv4.icanhazip.com);
MYIP2="s/xxxxxxxxx/$MYIP/g";
ether=`ifconfig | cut -c 1-8 | sort | uniq -u | grep venet0 | grep -v venet0:`
if [[ $ether = "" ]]; then
        ether=eth0
	fi
clear
	echo -e "===========( SQUID PORT )==============="    | boxes -d dog| lolcat -F 0.2
	echo -e "   ========================================" | lolcat -F 0.2
	echo -e "          SCRIPT MODD BY TAWONSUDIRO       " | lolcat -F 0.2
	echo -e "   WhatsApp Kami  : +6283148123457         " | lolcat -F 0.2
	echo -e "   FB Group       : GKNIGHT REBORN SSH     " | lolcat -F 0.2
	echo -e "   ========================================" | lolcat -F 0.2
	echo -e "   YOUTUBE CHANNEL: GKNIGHT GG             " | lolcat -F 0.2
	echo -e "                  : GKNIGHT REBORN         " | lolcat -F 0.2
	echo -e "   ========================================" | lolcat -F 0.2

read -p "Masukkan Port Squid dan pisahkan dengan 'spasi' setiap port: " port

#squid
rm -f /root/squidport
squidport="$(cat /etc/squid3/squid.conf | grep -i http_port | awk '{print $2}')"
echo ""
echo -e "Port Squid sebelum diedit:" | lolcat -F 0.2

cat > /root/squidport <<-END
$squidport
END

exec</root/squidport
while read line
do
	echo "Port $line"
	sed "/http_port $line/d" -i /etc/squid3/squid.conf
	#sed "s/Port $line//g" -i /etc/squid3/squid.conf
done
rm -f /root/squidport

echo ""

for i in ${port[@]}
do
	netstat -nlpt | grep -w "$i" > /dev/null
	if [ $? -eq 0 ]; then
		netstat -nlpt | grep -i squid | grep -w "$i" > /dev/null
		if [ $? -eq 0 ]; then
			sed -i "21 a\http_port $i" /etc/squid3/squid.conf
			echo -e "\e[032;1mPort $i sudah ditambahkan\e[0m"
		fi
		
		netstat -nlpt | grep -i sshd | grep -w "$i" > /dev/null
		if [ $? -eq 0 ]; then
			echo -e "\e[031;1mMaaf, Port $i sudah digunakan untuk OpenSSH\e[0m"
		fi
		
		netstat -nlpt | grep -i dropbear | grep -w "$i" > /dev/null
		if [ $? -eq 0 ]; then
			echo -e "\e[031;1mMaaf, Port $i sudah digunakan untuk Dropbear\e[0m"
		fi
		
		netstat -nlpt | grep -i openvpn | grep -w "$i" > /dev/null
		if [ $? -eq 0 ]; then
			echo -e "\e[031;1mMaaf, Port $i sudah digunakan untuk OpenVPN\e[0m"
		fi
	else
		sed -i "21 a\http_port $i" /etc/squid3/squid.conf
		echo -e "\e[92;1mPort $i sudah ditambahkan\e[0m"
	fi
done

echo ""
service squid3 restart

rm -f /root/squidport
squidport="$(cat /etc/squid3/squid.conf | grep -i http_port | awk '{print $2}')"
echo ""
echo -e "Port Squid sesudah diedit:" | lolcat -F 0.2

cat > /root/squidport <<-END
$squidport
END

exec</root/squidport
while read line
do
	echo "Port $line"
done
rm -f /root/squidport
	