#!/bin/bash

if [[ $USER != 'root' ]]; then
	echo "Maaf, Anda harus menjalankan ini sebagai root"
	exit
fi

MYIP=$(wget -qO- ipv4.icanhazip.com)

if ls /etc/block-situs.txt* 1> /dev/null 2>&1; then
clear

	cname=$( awk -F: '/model name/ {name=$2} END {print name}' /proc/cpuinfo )
	cores=$( awk -F: '/model name/ {core++} END {print core}' /proc/cpuinfo )
	freq=$( awk -F: ' /cpu MHz/ {freq=$2} END {print freq}' /proc/cpuinfo )
	tram=$( free -m | awk 'NR==2 {print $2}' )
	swap=$( free -m | awk 'NR==4 {print $2}' )
	up=$(uptime|awk '{ $1=$2=$(NF-6)=$(NF-5)=$(NF-4)=$(NF-3)=$(NF-2)=$(NF-1)=$NF=""; print }')
	date=$( date '+%A, %d %B %Y' )

	echo -e "===========( MENU BLOKIR )=============="    | boxes -d dog| lolcat -F 0.2
echo -e "   ========================================" | lolcat -F 0.2
echo -e "          SCRIPT MODD BY TAWONSUDIRO       " | lolcat -F 0.2
echo -e "   WhatsApp Kami  : +6283148123457         " | lolcat -F 0.2
echo -e "   FB Group       : GKNIGHT REBORN SSH     " | lolcat -F 0.2
echo -e "   ========================================" | lolcat -F 0.2
echo -e "   YOUTUBE CHANNEL: GKNIGHT GG             " | lolcat -F 0.2
echo -e "                  : GKNIGHT REBORN         " | lolcat -F 0.2
echo -e "   ========================================" | lolcat -F 0.2
	echo -e "                             Informasi Server Anda                             " | lolcat -F 0.2
	echo -e " IP/Host : $MYIP" | lolcat -F 0.2
	echo -e " Memory  : $tram MB" | lolcat -F 0.2
	echo -e " Date    : $date" | lolcat -F 0.2
	echo -e "===========( MENU BLOKIR )=============="    | boxes -d dog| lolcat -F 0.2
	echo -e "  1. Blokir IP/Website                       " | lolcat -F 0.2
	echo -e "  2. Lihat Daftar IP/Website yang diblokir                  " | lolcat -F 0.2
	echo -e "  3. Hapus IP/Website dari daftar blokir           " | lolcat -F 0.2
	echo -e ""
	echo -e " x >> Keluar"	 | lolcat -F 0.2
	echo -e ""
	read -p "Masukkan pilihan anda, kemudian tekan tombol ENTER : " option1
	echo ""
	case $option1 in
		1)
		wget -qcO /usr/binn/bw $source/Debian7/blocksite.sh && chmod +x /usr/binn/bw && cd /usr/binn/ && ./bw

		
		exit
		;;
		2)
		wget -qcO /usr/binn/lb $source/Debian7/listblocksite.sh && chmod +x /usr/binn/lb && cd /usr/binn/ && ./lb

		
		exit
		;;
		3)
		wget -qcO /usr/binn/ds $source/Debian7/delblocksite.sh && chmod +x /usr/binn/ds && cd /usr/binn/ && ./ds

		
		exit
		;;
		x)
		rm /root/IP

		
		exit
		;;
	esac

else
    echo " " > /etc/block-situs.txt
    echo "Update Selesai, silahkan jalankan ulang script ini."  | lolcat -F 0.2
	exit
	