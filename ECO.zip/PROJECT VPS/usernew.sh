#!/bin/bash
MYIP=$(wget -qO- ipv4.icanhazip.com)
clear
	echo -e "===============================" | lolcat -F 0.2
	echo -e "  SCRIPT MODD BY TAWONSUDIRO   " | lolcat -F 0.2
	echo -e "Kontak Kami WA : +6283148123457" | lolcat -F 0.2
	echo -e " FB Group: GKNIGHT REBORN SSH  " | lolcat -F 0.2
	echo -e "                               " | lolcat -F 0.2
	echo -e "===============================" | lolcat -F 0.2
	echo -e "       BUAT AKUN SSH           " | lolcat -F 0.2
	echo -e "===============================" | lolcat -F 0.2	
	read -p "username: " username
egrep "^$username" /etc/passwd >/dev/null
if [ $? -eq 0 ]; then
	echo "Username [$username] sudah ada!" | lolcat -F 0.2
	exit 1
else
	read -p "Password akun [$username]: " password
	read -p "Masa aktif akun [$username]: " AKTIF

	today="$(date +"%Y-%m-%d")"
	expire=$(date -d "$AKTIF days" +"%Y-%m-%d")
	useradd -M -N -s /bin/false -e $expire $username
	echo $username:$password | chpasswd
fi
	
    echo -e "===============================" | lolcat -F 0.2
    echo -e "    AKUN SSH YANG ANDA BUAT    " | lolcat -F 0.2
	echo -e "===============================" | lolcat -F 0.2
    echo "Host/IP      : $MYIP"               | lolcat -F 0.3
    echo "Port Dropbear: 109, 110, 443"       | lolcat -F 0.3
    echo "Port OpenSSH : 143"                 | lolcat -F 0.3
    echo "Squid Proxy  : 8080, 3128"          | lolcat -F 0.3
    echo "Username     : $username"           | lolcat -F 0.3
    echo "Password     : $password"           | lolcat -F 0.3
    echo "Aktif s/d    : $(date -d "$AKTIF days" +"%d-%m-%Y")" | lolcat -F 0.3
    echo -e "===============================" | lolcat -F 0.2
	echo -e "         RULES KAMI            "  
	echo -e "No DDOS,No CARDING,No SPAMMING "  
	echo -e "No TORENT, dan NO CYBER CRIME  " 
	echo -e "        MAX LOGIN 2 APP        "  
	echo -e "===============================" | lolcat -F 0.2
	echo -e "MELANGGAR RULES KAMI MAKA AKUN " 
	echo -e "    SECARA OTOMATIS DIBANNED   " 
	echo -e "===============================" | lolcat -F 0.2
	echo -e ""
	echo -e "  1. Menu Utama"                | lolcat -F 0.2
	echo -e "  2. Menu Akun  "               | lolcat -F 0.2
	read -p "Pilih dan  ENTER : " option1
	echo ""
	case $option1 in
		1)
		cd /root &&./minil.sh
		exit
		;;
		2)
		cd /root/baso/ && ./menuakun.sh
		exit
		;;
	esac
done