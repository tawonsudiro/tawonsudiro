#!/bin/bash
clear
	echo -e "===========(  LIST USER  )=============="    | boxes -d dog| lolcat -F 0.2
	echo -e "   ========================================" | lolcat -F 0.2
	echo -e "          SCRIPT MODD BY TAWONSUDIRO       " | lolcat -F 0.2
	echo -e "   WhatsApp Kami  : +6283148123457         " | lolcat -F 0.2
	echo -e "   FB Group       : GKNIGHT REBORN SSH     " | lolcat -F 0.2
	echo -e "   ========================================" | lolcat -F 0.2
	echo -e "   YOUTUBE CHANNEL: GKNIGHT GG             " | lolcat -F 0.2
	echo -e "                  : GKNIGHT REBORN         " | lolcat -F 0.2
	echo -e "   ========================================" | lolcat -F 0.2

echo "   ====================================" | lolcat -F 0.2
echo "  USERNAME              EXP DATE      " | lolcat -F 0.2
echo "   ------------------------------------" | lolcat -F 0.2

while read expired
do
	AKUN="   $(echo $expired | cut -d: -f1)"
	ID="  $(echo $expired | grep -v nobody | cut -d: -f3)"
	exp="   $(chage -l $AKUN | grep "Account expires" | awk -F": " '{print $2}')"
	if [[ $ID -ge 1000 ]]; then
		printf "%-21s %2s\n" "$AKUN" "$exp" | lolcat -F 0.2
	fi
done < /etc/passwd

JUMLAH="$(awk -F: '$3 >= 1000 && $1 != "nobody" {print $1}' /etc/passwd | wc -l)"

echo "------------------------------------" | lolcat -F 0.2
echo "Jumlah akun: $JUMLAH user" | lolcat -F 0.2
echo -e "   ========================================" | lolcat -F 0.2
	echo -e "          SCRIPT MODD BY TAWONSUDIRO       " | lolcat -F 0.2
	echo -e "   WhatsApp Kami  : +6283148123457         " | lolcat -F 0.2
	echo -e "   FB Group       : GKNIGHT REBORN SSH     " | lolcat -F 0.2
	echo -e "   ========================================" | lolcat -F 0.2
	echo -e "   YOUTUBE CHANNEL: GKNIGHT GG             " | lolcat -F 0.2
	echo -e "                  : GKNIGHT REBORN         " | lolcat -F 0.2
	echo -e "   ========================================" | lolcat -F 0.2